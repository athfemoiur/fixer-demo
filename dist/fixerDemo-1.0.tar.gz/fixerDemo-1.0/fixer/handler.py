def get_rates():
    print("success")
