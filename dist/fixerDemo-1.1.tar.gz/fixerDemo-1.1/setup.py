from setuptools import setup

setup(name='fixerDemo',
      version='1.1',
      description='Fixer service',
      author='athfemoiur',
      author_email='amirhossein.bonakdar@yahoo.com',
      url='#',
      packages=['fixer'],
      install_requires=["requests"]
      )
